﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SysdBLL;

namespace Late_night_Bookstore.nocodeinfo
{
    public partial class AddBook : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if(AddBookBLL.AddBook(TextBox1.Text,TextBox2.Text,TextBox3.Text,TextBox4.Text,TextBox5.Text,TextBox6.Text,TextBox7.Text,TextBox8.Text))
            {
                Literal txtmsg = new Literal();
                txtmsg.Text = "<Script>alert('添加成功')</Script>";
                Page.Controls.Add(txtmsg);
                Response.Redirect("~/info/Bookinfo.aspx");
            }
            else
            {
                Literal txtmsg = new Literal();
                txtmsg.Text = "<Script>alert('添加失败')</Script>";
                Page.Controls.Add(txtmsg);
            }
        }
    }
}