﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SysdBLL;

namespace Late_night_Bookstore.nocodeinfo
{
    public partial class AddCategory : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCotegory_Click(object sender, EventArgs e)
        {
            if(AddCategoryBLL.addCategory(TextBox1.Text,TextBox2.Text,TextBox3.Text))
            {
                Literal txtmsg = new Literal();
                txtmsg.Text = "<Script>alert('添加成功')</Script>";
                Page.Controls.Add(txtmsg);
                Response.Redirect("AddBook.aspx");
            }
            else
            {
                Literal txtmsg = new Literal();
                txtmsg.Text = "<Script>alert('添加失败')</Script>";
                Page.Controls.Add(txtmsg);
            }

        }
    }
}