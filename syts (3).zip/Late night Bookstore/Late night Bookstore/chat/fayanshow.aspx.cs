﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Late_night_Bookstore.chat
{
    public partial class fayanshow : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //传递方法四
            Label1.Text = Session["UserName"].ToString();

            if (!Page.IsPostBack)
            {
                Application.Lock();
                if (Application["user_sum"] == null)
                {
                    Application["user_sum"] = 0;
                }
                Application["user_sum"] = (int)Application["user_sum"] + 1;
                Label2.Text = Application["user_sum"].ToString();
                Application.UnLock();
            }
        }

        protected void btnClearSpeak_Click(object sender, EventArgs e)
        {
            Application.Clear();
        }

        protected void btnfayan_Click(object sender, EventArgs e)
        {
            string str = "IP地址：" + Request.UserHostAddress + "<hr>";
            str += "发言者：" + Session["UserName"].ToString() + "<hr>";
            str += "发言时间：" + DateTime.Now.ToString() + "<hr>";
            str += "发言内容：" + TextBox1.Text + "<hr>";

            Application.Lock();
            Application["message"] = str + Application["message"];
            Application.UnLock();
            TextBox1.Text = "";
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}