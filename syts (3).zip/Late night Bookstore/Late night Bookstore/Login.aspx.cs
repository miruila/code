﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SysdBLL;
using SysdModel;

namespace Late_night_Bookstore
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (LoginBLL.Login(txtUserName.Text, txtUserPwd.Text))
            {
                Session["UserName"] = txtUserName.Text;
                tblUser.UserName = txtUserName.Text;

                Response.Write("<Script>alert('成功')</Script>");
                Response.Redirect("Test.aspx");
            }
            else
            {
                Response.Write("<Script>alert('登陆失败')</Script>");
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Register.aspx");
        }
    }
}