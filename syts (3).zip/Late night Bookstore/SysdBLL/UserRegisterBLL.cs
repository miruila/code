﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SysdDAL;

namespace SysdBLL
{
    public static class UserRegisterBLL
    {

        public static Boolean UsersRegister(string strb1, string strb2, string strb3)
        {
            return UserRegisterDAl.UsersRegister(strb1, strb2, strb3);
        }

    }
}
