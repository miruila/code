﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SysdDAL;

namespace SysdBLL
{
     public static class AddBookBLL
    {
         public static Boolean AddBook(string strb1, string strb2, string strb3, string strb4, string strb5, string strb6, string strb7, string strb8) 
         {
             return AddBookDAL.AddBook(strb1, strb2, strb3, strb4, strb5, strb6, strb7, strb8);
         }
    }
}
