﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SysdDAL;

namespace SysdBLL
{
    public static class AddCategoryBLL
    {
        public static Boolean addCategory(string strb1, string strb2, string strb3)
        {
            return AddCategoryDAL.addCategor(strb1, strb2, strb3);
        }
    }
}
