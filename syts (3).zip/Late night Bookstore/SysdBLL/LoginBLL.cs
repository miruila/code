﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SysdDAL;

namespace SysdBLL
{
    public static class LoginBLL
    {
        public static Boolean Login(string str1Bll, string str2Bll)
        {
            return LoginDAl.Login(str1Bll,str2Bll);
        }
    }
}
