﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SysdModel
{
    public static class tblUser
    {
        public static string UserName;
        public static string UserPwd;
    }
}
