﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace SysdDAL
{
    public static class LoginDAl
    {
        public static Boolean Login(string str1dal, string str2dal)
        {
            Boolean state = false;

            string sqlcomm = string.Format("select COUNT(*) from Users where UserName='{0}'and Password='{1}' ", str1dal, str2dal);
            try
            {
                DBhelp.con.Open();
                SqlCommand cmd = new SqlCommand(sqlcomm, DBhelp.con);
                if ((int)cmd.ExecuteScalar() > 0)
                {
                    state = true;
                }

            }
            catch (Exception)
            {
                state = false;
            }
            finally
            {
                DBhelp.con.Close();
            }

            return state;
        }
        }}