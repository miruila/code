﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace SysdDAL
{
    public static class BookinfoDAL
    {
        public static DataTable getBookinfoDAL() 
        {
            DataTable dst = new DataTable();
            DataSet set = new DataSet();
            try
            {
                DBhelp.con.Open();
                string sql = "select * from Book";
                SqlDataAdapter da = new SqlDataAdapter(sql, DBhelp.con);
                da.Fill(set, "Book");
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message, ex);
            }
            finally
            {
                DBhelp.con.Close();
            }
            dst = set.Tables[0];
            return dst;
        }
    }
}
