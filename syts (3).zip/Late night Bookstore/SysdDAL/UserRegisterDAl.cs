﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace SysdDAL
{
    public static class UserRegisterDAl
    {

        public static Boolean UsersRegister(string str1, string str2, string str3)
        {
            Boolean statue = false;

            string sqlcomm = string.Format("insert into Users(UserName,RealName,Password)values('{0}','{1}','{2}') ", str1, str2, str3);
            try
            {
                DBhelp.con.Open();
                SqlCommand cmd = new SqlCommand(sqlcomm, DBhelp.con);
                if ((int)cmd.ExecuteNonQuery() > 0)
                {
                    statue = true;
                }
            }
            catch (Exception)
            { }
            finally
            {
                DBhelp.con.Close();
            }
            return statue;
        }
    }
}
