﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace SysdDAL
{
    public static class AddBookDAL
    {
        public static Boolean AddBook(string str1, string str2, string str3,
            string str4, string str5, string str6, string str7, string str8)
        {
            Boolean statue = false;

            string sqlcomm = string.Format("insert into Book(BookID,Name,CategoryID,Author,Price,TotalNum,ISBN,pic)values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}') ", str1, str2, str3,str4,str5,str6,str7,str8);
            try
            {
                DBhelp.con.Open();
                SqlCommand cmd = new SqlCommand(sqlcomm, DBhelp.con);
                if ((int)cmd.ExecuteNonQuery() > 0)
                {
                    statue = true;
                }
            }
            catch (Exception)
            { }
            finally
            {
                DBhelp.con.Close();
            }
            return statue;
        }
    }
}
