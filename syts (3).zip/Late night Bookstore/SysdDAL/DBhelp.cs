﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace SysdDAL
{
    public static class DBhelp
    {
        static string sqlcon = "Data Source=.;Initial Catalog=Sysd;Integrated Security=True";
        public static SqlConnection con = new SqlConnection(sqlcon);
    }
}
